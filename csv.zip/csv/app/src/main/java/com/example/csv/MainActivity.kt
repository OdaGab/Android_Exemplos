package com.example.csv
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVParser
import java.io.BufferedReader

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    
        setContentView(R.layout.activity_main)

        createCSVFile()
        
    }

    private fun createCSVFile() {
        val textView = findViewById<TextView>(R.id.tvCsv)

        val bufferReader = BufferedReader(assets.open("Alunos.csv").reader())
        val csvParcer = CSVParser.parse(
            bufferReader,
            CSVFormat.DEFAULT
        )
        val list= mutableListOf<Alunos>()
        csvParcer.forEach {
            it?.let {
            val cities =Alunos(
                ra = it.get(0),
                turma = it.get(1),
                aluno = it.get(2)
            )
                list.add(cities)
        }
      }
        list.forEach {
            textView.append(
                "${it.ra} - ${it.turma} - ${it.aluno} \n"
            )


        }
    }
}