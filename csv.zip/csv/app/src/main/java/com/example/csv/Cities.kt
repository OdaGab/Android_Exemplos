package com.example.csv

data class Alunos(
    val ra: String,
    val turma: String,
    val aluno: String,

)
