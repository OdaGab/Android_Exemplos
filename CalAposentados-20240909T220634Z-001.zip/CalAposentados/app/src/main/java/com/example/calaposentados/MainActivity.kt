package com.example.calaposentados

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //definindo o arquivo de layout
        setContentView(R.layout.activity_main)

        //Acessando os objetos
        val spinnerSexo = findViewById<Spinner>(R.id.spiner_sexo)
        val editTextIdade = findViewById<EditText>(R.id.edit_text_idade)
        val buttonCalcular = findViewById<Button>(R.id.button_calcular)
        val textResultado = findViewById<TextView>(R.id.text_view_resultado)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("masculino", "feminino")
        )
        spinnerSexo.adapter = ArrayAdapter<String>(this, android.R.layout
            .simple_spinner_dropdown_item,
            listOf("masculino", "feminino"))

        spinnerSexo.adapter = adapter

        buttonCalcular.setOnClickListener{
            //capturando o sexo selecionado
            val sexo = spinnerSexo.selectedItem as String

            //capturando a idade digitada
            val idade = editTextIdade.text.toString().toInt()

            //variavel para guardar o resultado do calculo
            var resultado = 0

            //verificando o sexo da pessoa
            if(sexo == "masculino"){
                resultado = 65 - idade
            }else{
                resultado = 60 - idade
            }

            //Atualizando a tela de acordo com o resultado do calculo
            textResultado.text = "Faltam $resultado anos para você se aposentar."

        }
    }
}